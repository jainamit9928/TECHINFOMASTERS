import _ from 'lodash'

export const getPreferedTechies = (techies, preferedTechies) => _.filter(techies, (techie) => {
    return _.includes(preferedTechies, techie.id)
})
