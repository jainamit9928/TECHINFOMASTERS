import * as types from '../constants/constants.js'

export const setShippingDetail = (data) => ({ type: types.SET_SHIPPING_DETAIL, data })
//export const setReceiverDetail = (data) => ({ type: types.SET_RECEIVER_ADDRESS, data })
//export const setShippingOption = (data) => ({ type: types.SET_SHIPPING_OPTION, data })
//export const setWeight = (data) => ({ type: types.SET_WEIGHT, data })
export const setSteps = (data) => ({ type: types.SET_STEPS, data })
