import React from 'react'

export default class Home extends React.PureComponent {

    componentDidMount() {
     console.log("Home component Mounted")
    }

    render() {
        
        return (
           
                <div className='component-block'>
                
                        <div className='col-md-12'>
                         <h2> Home Page</h2>
                          Here you can add items to your cart.<br/>
                          <strong>Page is Under Development. For Shipping Details ,Go to Shipping Page.</strong>
                          
                        </div>
                   
                </div>
           
        )
    }
}

