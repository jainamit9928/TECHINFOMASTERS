import React from 'react'
import { RECEIVER_HEADER, SENDER_HEADER } from '../../constants/constants'
import Loader from 'react-loader'
import AddressDetail from '../features/shippinglabelmaker/addressDetail.jsx'

export default class Widget extends React.PureComponent {

    componentDidMount() {
     
    }

    render() {
    const { steps , hasError, onChange, onUpdate, goForwad, goBack} =  this.props
    switch (this.props.steps) {
         
			case 1:
				return <AddressDetail header ={ RECEIVER_HEADER } addressType="receiver" address = { this.props.shippingDetail.receiverDetails } steps = { steps } hasError ={ hasError } onChange = { onChange } onUpdate ={ onUpdate } goForwad = { goForwad } goBack = { goBack } />
			case 2:
				return <AddressDetail header ={ SENDER_HEADER } addressType="sender" address = { this.props.shippingDetail.senderDetails } steps = { steps } hasError ={ hasError } onChange = { onChange } onUpdate ={ onUpdate } goForwad = { goForwad } goBack = { goBack } />
            default:
                return <AddressDetail />  
		}
        
	
        
    }
}

