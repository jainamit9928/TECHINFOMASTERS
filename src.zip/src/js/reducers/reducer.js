import * as actionTypes from '../constants/constants.js'


export const shippingDetail=(state = { steps:1 , detail:{ receiverDetails:{name:"", street:"", city:"", state:"" }, senderDetails:{ name:"", street:"", city:"", state:"" }, weight:{value:null}, shippingOption:{ ground:1, priority:2 } } }, action) => {
    switch (action.type) {

        case actionTypes.SET_DATA:
            return Object.assign({}, state, {
                detail:action.data
            }
            );
        case actionTypes.SET_STEPS:
            return Object.assign({}, state, {
              step:action.data
            })

        default:
            return state;
    }
}
