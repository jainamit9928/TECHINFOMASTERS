import { connect } from 'react-redux'
import Home from '../components/home/home'
import { bindActionCreators } from 'redux'


 const mapStateToProps = (state, props) => {
         return {
           
        }
  }
 
const mapDispatchToProps = (dispatch) => {
      return {
    
    }
}
const HomeContainer =connect(mapStateToProps, mapDispatchToProps)(Home);
export default HomeContainer
