import * as stateActions from '../actions/actions'
import { connect } from 'react-redux'
import ShippingLabelMaker from '../components/features/shippinglabelmaker/shippingLabelMaker'
import { bindActionCreators } from 'redux'

const mapStateToProps = (state, props) => {
        return {
           shippingDetail:state.shippingDetail.detail,
           steps:state.shippingDetail.steps
        }

}

const mapDispatchToProps = (dispatch) => {
    return {
        actions:bindActionCreators(stateActions, dispatch),
    }
}
const ShippingLabelMakerContainer =connect(mapStateToProps, mapDispatchToProps)(ShippingLabelMaker)
export default ShippingLabelMakerContainer
